package com.mouritech.onlinefoodorderapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinefoodorderapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
