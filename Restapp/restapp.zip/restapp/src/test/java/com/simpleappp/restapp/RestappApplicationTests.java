package com.simpleappp.restapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestappApplicationTests {

	@Test
	void contextLoads() {
	}

}
